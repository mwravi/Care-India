package com.careindia.lifeskills.views.HomeScreen

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.careindia.lifeskills.R
import com.careindia.lifeskills.views.activities.HouseholdProfileListActivity
import com.careindia.lifeskills.views.activities.MainActivity
import com.careindia.lifeskills.views.activities.PrimaryDataListActivity
import com.careindia.lifeskills.views.activity.CollectProfileListActivity
import com.careindia.lifeskills.views.base.BaseActivity
import kotlinx.android.synthetic.main.activity_home_dashboard.*

class HomeDashboardActivity : BaseActivity(), View.OnClickListener {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_dashboard)

        initializeController()
    }



    override fun initializeController() {
        applyClickOnView()

    }

    /**
     * Click on view
     */
    private fun applyClickOnView() {
        linear_household.setOnClickListener(this)
        linear_individual.setOnClickListener(this)
        linear_collective_prf.setOnClickListener(this)
        linear_prgrs_trckr.setOnClickListener(this)

    }

    override fun onClick(view: View?) {
        when(view?.id){
            R.id.linear_household ->{
                var intent = Intent(this, HouseholdProfileListActivity::class.java)
                startActivity(intent)
            }
            R.id.linear_individual ->{
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            R.id.linear_collective_prf ->{
                var intent = Intent(this, CollectProfileListActivity::class.java)
                startActivity(intent)
            }
            R.id.linear_prgrs_trckr ->{
                var intent = Intent(this, PrimaryDataListActivity::class.java)
                startActivity(intent)
            }
        }
    }


}
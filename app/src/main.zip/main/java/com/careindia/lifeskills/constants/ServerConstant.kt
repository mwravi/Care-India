package com.careindia.lifeskills.constants

object ServerConstant {
    const val LOGIN = "api/v1/userLogin"
}
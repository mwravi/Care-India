package com.careindia.lifeskills.listeners

interface GetCallBackCampaign {
    fun getCampaignId(campaignId:String)
}
package com.careindia.lifeskills.application

import android.os.Build
import android.os.StrictMode
import androidx.multidex.MultiDexApplication
import androidx.room.Room
import com.careindia.lifeskills.database.AppDataBase
import com.careindia.lifeskills.di.dataModules
import com.careindia.lifeskills.di.repositoryModules
import com.careindia.lifeskills.di.variableModules
import com.careindia.lifeskills.di.viewModelModules
import org.koin.android.ext.android.startKoin

class CareIndiaApplication : MultiDexApplication() {

    private val DB_NAME = "CAREINDIA_DB.db"

    companion object {
        var database: AppDataBase? = null
        lateinit var myApplication: CareIndiaApplication

    }

    override fun onCreate() {
        super.onCreate()
        myApplication = this
        // get all modules
        val moduleList =
            viewModelModules + dataModules + repositoryModules + variableModules
        // set the module list
        startKoin(this, moduleList)
        database =
            Room.databaseBuilder(applicationContext, AppDataBase::class.java, DB_NAME)
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries().build()

        if (Build.VERSION.SDK_INT >= 24) {
            val builder = StrictMode.VmPolicy.Builder()
            StrictMode.setVmPolicy(builder.build())
        }
        if (Build.VERSION.SDK_INT > 9) {
            val policy =
                StrictMode.ThreadPolicy.Builder().permitAll().build()
            StrictMode.setThreadPolicy(policy)
        }
    }

    fun getDataBaseObj(): AppDataBase? {
        return database
    }



}
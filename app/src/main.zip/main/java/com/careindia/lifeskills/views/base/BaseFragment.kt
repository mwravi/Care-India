package com.careindia.lifeskills.views.base

import androidx.fragment.app.Fragment

abstract class BaseFragment : Fragment() {

    abstract fun initializerControl()
}
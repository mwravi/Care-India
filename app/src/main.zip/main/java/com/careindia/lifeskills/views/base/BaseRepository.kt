package com.careindia.lifeskills.views.base

import com.careindia.lifeskills.network.RestClient


abstract class BaseRepository {

   protected val apiHelper = RestClient.createApiHelper()

}
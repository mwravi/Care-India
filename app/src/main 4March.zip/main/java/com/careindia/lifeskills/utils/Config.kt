package com.careindia.lifeskills.utils.extentions


class Config {
    // var VersionNo = BuildConfig.VERSION_NAME
    val BASE_URL = "http://ciewp.microwarecorp.com/"
//    val BASE_URL = "https://ewp.careindia.org/"
//    val BASE_URL1 = "https://ewp.careindia.org/"

}
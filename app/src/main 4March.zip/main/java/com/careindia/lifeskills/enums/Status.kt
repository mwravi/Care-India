package com.careindia.lifeskills.enums
enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
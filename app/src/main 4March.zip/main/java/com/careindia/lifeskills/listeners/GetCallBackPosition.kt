package com.careindia.lifeskills.listeners

interface GetCallBackPosition {
    fun getCallBack(position:Int)
}
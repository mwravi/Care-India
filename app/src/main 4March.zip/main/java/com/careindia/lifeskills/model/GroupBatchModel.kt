package com.careindia.lifeskills.model


data class GroupBatchModel(
    var guid: String,
    var id: Int
)

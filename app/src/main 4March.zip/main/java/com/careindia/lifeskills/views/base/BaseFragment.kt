package com.careindia.lifeskills.ui.base

import androidx.fragment.app.Fragment

abstract class BaseFragment : Fragment() {

    abstract fun initializerControl()
}
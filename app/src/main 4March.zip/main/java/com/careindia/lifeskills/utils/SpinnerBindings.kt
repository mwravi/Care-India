package com.careindia.lifeskills.utils

import android.widget.Spinner
import androidx.databinding.BindingAdapter

class SpinnerBindings {

//    @BindingAdapter("entries")
//    fun Spinner.setEntries(entries: List<Any>?) {
//        setSpinnerEntries(entries)
//    }
//
//    @BindingAdapter("onItemSelected")
//    fun Spinner.setItemSelectedListener(itemSelectedListener: ItemSelectedListener?) {
//        setSpinnerItemSelectedListener(itemSelectedListener)
//    }
//
//    @BindingAdapter("newValue")
//    fun Spinner.setNewValue(newValue: Any?) {
//        setSpinnerValue(newValue)
//    }
}
package com.careindia.lifeskills.listeners

import android.app.Dialog

interface GetCallBackDialog {
    fun getCallBack(dialog:Dialog)
}